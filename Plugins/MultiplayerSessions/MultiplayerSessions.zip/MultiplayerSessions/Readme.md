先在项目的config文件夹中DefaultEngine.ini中找到[/Script/Engine.GameEngine]一项，从这项开始添加如下信息，要是没有这项就在文件末尾加，这里的目的是设置你在Steam上的产品Id，以及告诉引擎是否使用以及使用哪个在线会话平台

```
[/Script/Engine.GameEngine]
+NetDriverDefinitions=(DefName="GameNetDriver",DriverClassName="OnlineSubsystemSteam.SteamNetDriver",DriverClassNameFallback="OnlineSubsystemUtils.IpNetDriver")

[OnlineSubsystem]
DefaultPlatformService=Steam

[OnlineSubsystemSteam]
bEnabled=true
SteamDevAppId=480
bInitServerOnClient=true
; If using Sessions
; bInitServerOnClient=true

[/Script/OnlineSubsystemSteam.SteamNetDriver]
NetConnectionClassName="OnlineSubsystemSteam.SteamNetConnection"

[/Script/OnlineSubsystemUtils.IpNetDriver]
NetServerMaxTickRate=60
```

随后在工程的build.cs文件中添加这个插件模块，在PublicDependencyModuleNames.AddRange中加入

```
PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				//联机子系统的模块
				"OnlineSubsystem",
				"OnlineSubsystemSteam",
				//菜单界面要用到的模块添加到这
				 "UMG",
				 "Slate",
				 "SlateCore"
				// ... add other public dependencies that you statically link with here ...
			}
			);
```

随后编译项目，如果不是C++工程，我记得直接运行项目.uproject也会自动编译插件。

使用很简单，就两个UI

![image-20230523204320121](Readme/image-20230523204320121.png)

第二个都不用管，第一个WBP_Menu用的时候直接添加到视口就能直接使用。就三个按钮

![image-20230523210219318](Readme/image-20230523210219318.png)

其中创建房间和加入房间的逻辑写在C++中，事件构造用于初始化要加入或创建的房间信息，具体的参数用户自己改，各参数意义如下。

![image-20230523204546701](Readme/image-20230523204546701.png)

第二个参数是房间能容纳最大的玩家数量，默认给的一百，可以自己改。

第三个参数是房间的名称，玩家只能加入房间名一致的房间，因为查找房间就是根据房间名查找的。比如创建一个房间叫110,那么别的玩家要想进入你的房间，这个参数必须也是110，然后点击加入房间才能加进去。

如果想要加入不同的房间，可以稍微修改一下UI界面，添加一个编辑框，自己输入要加入房间的名字来更改MatchType的值就行。(Type Of Match是MenuSetup函数的形参，背后实际上起作用的值是MatchType)

![image-20230523205526134](Readme/image-20230523205526134.png)

第四个参数就是要玩家加入的地图的路径。右键你的地图，点击复制引用，比如我选了一个地图的复制引用，得到的是 /Script/Engine.World'/Game/Map/LobbyMap.LobbyMap' ，取其后半段并去掉末尾即可：

/Game/Map/LobbyMap 。

要更改加入的地图方法同上，设置PathToLobby的值即可

![image-20230523205946012](Readme/image-20230523205946012.png)

插件是以监听服务器的方式创建在线会话的，谁创建的房间谁就是房主，就是服务端，网络延时最低的将是房主，在服务端计算的数据均以房主的机器为准。

房主创建好房间后，其它玩家点击加入房间后几秒内大概率是没反应的，需要耐心等待，大概七八十几秒才能加进去，具体时间取决于网络，反正国内不开加速器稀烂。

对于测试，UE5之后需要将涉及到的地图资产添加打包列表中才能打包出来，因为联机是通过steam平台进行的，所以你需要两个steam账号以及两台机器才能进行联机测试，或者你可以在本地使用虚拟机进行测试。

![image-20230524090455554](Readme/image-20230524090455554.png)